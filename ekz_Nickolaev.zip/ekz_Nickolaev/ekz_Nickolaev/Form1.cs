﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ekz_Nickolaev
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            view_box.Items.Clear();
            string asd = textBox1.Text;
            string conStr = string.Format("SELECT\r\n    o.OrderID,\r\n    c.FullName AS ClientName,\r\n    e.FullName AS EmployeeName,\r\n    " +
                "e.Position AS EmployeePosition,\r\n    o.ShootingDate,\r\n    o.CompletionDate,\r\n    o.Cost\r\nFROM Orders o\r\nJOIN Clients c " +
                "ON o.ClientID = c.ClientID\r\nJOIN Employees e ON o.EmployeeID = e.EmployeeID\r\nWHERE o.ShootingDate = {0}\r\n" +
                "ORDER BY o.CompletionDate;\r\n", asd);
            using (SqlConnection con = new SqlConnection(Program.conStr))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(conStr, con);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string row = null;
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row += reader.GetName(i) + " : " + reader[i] + " ";
                            }
                            view_box.Items.Add(row);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            view_box.Items.Clear();   
            string conStr = string.Format("SELECT\r\n    e.EmployeeID,\r\n    e.FullName,\r\n    e.Position,\r\n    YEAR(o.CompletionDate) AS Year,\r\n    " +
                "MONTH(o.CompletionDate) AS Month,\r\n    SUM(o.Cost) AS TotalOrderAmount,\r\n    " +
                "SUM(o.Cost) * 0.4 AS Salary\r\nFROM Employees e\r\nJOIN Orders o ON e.EmployeeID = o.EmployeeID\r\nWHERE o.Status = 'Выполнен'\r\n" +
                "GROUP BY\r\n    e.EmployeeID,\r\n    e.FullName,\r\n    e.Position,\r\n    YEAR(o.CompletionDate),\r\n    MONTH(o.CompletionDate)\r\n" +
                "ORDER BY\r\n    Year,\r\n    Month,\r\n    TotalOrderAmount DESC;\r\n");
            using (SqlConnection con = new SqlConnection(Program.conStr))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(conStr, con);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string row = null;
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row += reader.GetName(i) + " : " + reader[i] + " ";
                            }
                            view_box.Items.Add(row);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            view_box.Items.Clear();
            string conStr = string.Format("SELECT\r\n    e.EmployeeID,\r\n    e.FullName,\r\n    e.Position,\r\n    " +
                "COUNT(DISTINCT o.ClientID) AS UniqueClientsCount,\r\n    COUNT(o.OrderID) AS TotalOrders\r\nFROM Employees e\r\n" +
                "JOIN Orders o ON e.EmployeeID = o.EmployeeID\r\nGROUP BY\r\n    e.EmployeeID,\r\n    e.FullName,\r\n    " +
                "e.Position\r\nORDER BY\r\n    UniqueClientsCount DESC,\r\n    TotalOrders DESC;\r\n");
            using (SqlConnection con = new SqlConnection(Program.conStr))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(conStr, con);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string row = null;
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row += reader.GetName(i) + " : " + reader[i] + " ";
                            }
                            view_box.Items.Add(row);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
